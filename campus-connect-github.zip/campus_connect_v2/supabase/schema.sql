create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null, student_id text not null, department text not null, semester text not null,
 created_at timestamptz not null default now()
);
create table if not exists public.services (
 id uuid primary key default gen_random_uuid(), provider_id uuid not null references public.profiles(id) on delete cascade,
 title text not null check(char_length(title) between 3 and 90), category text not null,
 description text not null check(char_length(description)<=600), price numeric(10,2) not null check(price>=0),
 unit text not null default 'per project', portfolio_url text, contact text,
 is_active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.service_requests (
 id uuid primary key default gen_random_uuid(), service_id uuid not null references public.services(id) on delete cascade,
 provider_id uuid not null references public.profiles(id) on delete cascade,
 requester_id uuid not null references public.profiles(id) on delete cascade,
 message text not null, status text not null default 'pending' check(status in('pending','accepted','completed','cancelled')),
 created_at timestamptz not null default now(), check(provider_id<>requester_id)
);
create table if not exists public.reviews (
 id uuid primary key default gen_random_uuid(), service_id uuid not null references public.services(id) on delete cascade,
 reviewer_id uuid not null references public.profiles(id) on delete cascade,
 stars int not null check(stars between 1 and 5), body text not null check(char_length(body) between 3 and 500),
 created_at timestamptz not null default now(), unique(service_id,reviewer_id)
);
alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.service_requests enable row level security;
alter table public.reviews enable row level security;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path='' as $$
begin insert into public.profiles(id,full_name,student_id,department,semester) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','Student'),coalesce(new.raw_user_meta_data->>'student_id','Pending verification'),coalesce(new.raw_user_meta_data->>'department','Not specified'),coalesce(new.raw_user_meta_data->>'semester','Not specified')); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
create policy "Signed in users can view profiles" on public.profiles for select to authenticated using(true);
create policy "Users update own profile" on public.profiles for update to authenticated using(auth.uid()=id) with check(auth.uid()=id);
create policy "Active services public read" on public.services for select using(is_active=true);
create policy "Provider creates own service" on public.services for insert to authenticated with check(provider_id=auth.uid());
create policy "Provider updates own service" on public.services for update to authenticated using(provider_id=auth.uid()) with check(provider_id=auth.uid());
create policy "Provider deletes own service" on public.services for delete to authenticated using(provider_id=auth.uid());
create policy "Participants view requests" on public.service_requests for select to authenticated using(requester_id=auth.uid() or provider_id=auth.uid());
create policy "Student sends request" on public.service_requests for insert to authenticated with check(requester_id=auth.uid() and provider_id<>auth.uid());
create policy "Participants update request" on public.service_requests for update to authenticated using(requester_id=auth.uid() or provider_id=auth.uid()) with check(requester_id=auth.uid() or provider_id=auth.uid());
create policy "Reviews public read" on public.reviews for select using(true);
create policy "Student writes own review" on public.reviews for insert to authenticated with check(reviewer_id=auth.uid());
-- Before production: enforce review eligibility with a completed request using a secure database function/trigger;
-- add admin verification for CU Jammu student status; add stricter request update rules and moderation.
