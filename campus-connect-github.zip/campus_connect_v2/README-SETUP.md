# Campus Connect — GitHub Pages + Supabase setup

A responsive CU Jammu student-services marketplace starter. Students can register, list services, set starting rates, add portfolio links, request services and submit reviews. No in-app payments in this launch.

## Publish free on GitHub Pages
1. Create a public GitHub repository named `campus-connect`.
2. Upload `index.html`, this README and the `supabase` folder.
3. Open repository **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. GitHub Pages will publish a URL like `https://YOUR-USERNAME.github.io/campus-connect/`.

## Enable real shared registrations/listings/reviews
GitHub Pages only hosts files; it does not store shared data. To make all students see the same registrations, services and reviews:
1. Create a free project at https://supabase.com/.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Supabase Project Settings → API, copy the Project URL and anon/public key.
4. Edit `index.html`; replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_KEY` near the bottom.
5. Commit and push the updated file to GitHub.
6. In Supabase Authentication → URL Configuration, add your GitHub Pages URL to Site URL and Redirect URLs.
7. Test with two different student accounts and devices before launch.

**Never put a Supabase service-role key in browser code.** The anon/public key is designed for browser use with Row Level Security enabled.

## CU Jammu-only access and safety
The signup form asks for university email, student ID/roll number, department and semester. Do not assume a university email suffix without confirming the official domain. Until domain verification or admin approval is configured, eligibility is not automatically verified. This starter labels the platform as an independent student initiative, not an official CU Jammu service. Avoid collecting ID scans or other sensitive documents in public portfolios.

## MVP limitations
- Sample service cards are demo content, not real providers.
- Requests are saved in the database, but a provider/requester dashboard and notifications are not included yet.
- Reviews are authenticated but this starter does not yet enforce a completed request before review; add that server-side rule before treating reviews as verified.
- No escrow, payment processing, dispute/refund handling or moderation dashboard. Students coordinate payment independently at their own risk.
- Configure Supabase and test security policies before sharing publicly.
